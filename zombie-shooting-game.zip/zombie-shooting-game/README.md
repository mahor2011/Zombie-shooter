# Zombie Shooting Game

A Pen created on CodePen.

Original URL: [https://codepen.io/Zehn1984/pen/BaqRxRK](https://codepen.io/Zehn1984/pen/BaqRxRK).

A zombie shooting game with sounds, timer, bullets, and other mechanics.
I`ve forked it from this guy: https://codepen.io/codegrind6/pen/gOmamra
I thank him for inspiring me to do this one, and I hope i inspire others too. :-)